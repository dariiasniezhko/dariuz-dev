import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DepositoInterface extends Remote {
	void inserisci(Roba v) throws RemoteException;
	Roba estrazione(int quality) throws RemoteException;
}
