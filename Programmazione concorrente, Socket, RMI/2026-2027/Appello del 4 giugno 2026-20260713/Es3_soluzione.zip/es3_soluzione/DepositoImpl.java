import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class DepositoImpl extends UnicastRemoteObject implements DepositoInterface {
	private static final long serialVersionUID = 1L;
	Deposito ilDeposito;
	DepositoImpl() throws RemoteException{
		super();
		ilDeposito=new Deposito(4);
	}
	public void inserisci(Roba v) throws RemoteException {
		ilDeposito.inserisci(v);		
	}
	public Roba estrazione(int quality) throws RemoteException {
		return ilDeposito.estrazione(quality);
	}
	public static void main(String[] args) {
		try {
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("ProdConsQuality", new DepositoImpl());
			System.out.println("Server running");
		} catch (RemoteException e) {
			System.err.println("Server failure");
		}
	}
}
