import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.ThreadLocalRandom;

public class Produttore {
	DepositoInterface ilDeposito;
	Produttore(DepositoInterface dep){
		ilDeposito=dep;
	}
	private void dormitina() {
		try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(200));
		} catch (InterruptedException e) {	}
	}
	public void exec() throws RemoteException {
		Roba r;
		Thread.currentThread().setName("prod_"+System.currentTimeMillis()%1000);
		while(true) {
			dormitina();
			r=new Roba("descr",ThreadLocalRandom.current().nextInt(100));
			ilDeposito.inserisci(r);
		}
	}
	public static void main(String[] args) {
		try {
			Registry reg=LocateRegistry.getRegistry(1099);
			DepositoInterface dep = (DepositoInterface) reg.lookup("ProdConsQuality");
			new Produttore(dep).exec();
		} catch (RemoteException | NotBoundException e) {
			System.err.println("Producer failure");
		}
	}
}
