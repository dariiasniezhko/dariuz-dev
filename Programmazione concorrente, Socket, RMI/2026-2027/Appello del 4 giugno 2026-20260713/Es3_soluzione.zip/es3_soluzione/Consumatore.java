import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.ThreadLocalRandom;

public class Consumatore {
	DepositoInterface ilDeposito;
	Consumatore(DepositoInterface dep){
		ilDeposito=dep;
	}
	private void dormitina() {
		try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(200));
		} catch (InterruptedException e) {	}
	}
	public void exec() throws RemoteException {
		Roba r=null;
		boolean preso;
		int quality;
		Thread.currentThread().setName("cons_"+System.currentTimeMillis()%1000);
		while(true) {
			preso=false;
			quality=98;
			while(!preso) {
				r=ilDeposito.estrazione(quality);
				preso=(r!=null);
				quality-=5;
				quality=Math.max(0, quality-5);
			}
			dormitina();  // uso 
		}
	}
	public static void main(String[] args) {
		try {
			Registry reg=LocateRegistry.getRegistry(1099);
			DepositoInterface dep = (DepositoInterface) reg.lookup("ProdConsQuality");
			new Consumatore(dep).exec();
		} catch (RemoteException | NotBoundException e) {
			System.err.println("Consumer failure");
		}
	}
}
