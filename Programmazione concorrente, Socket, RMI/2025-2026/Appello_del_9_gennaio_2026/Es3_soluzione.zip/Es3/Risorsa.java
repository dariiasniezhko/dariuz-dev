import java.util.HashMap;

public class Risorsa {
	final int TOT=6;
	String laRisorsa;      // non rilevante
	HashMap<TipoUtente, Long> attesaUtenti;  // quando ha iniziato l'attesa ogni tipo di utente
	TipoUtente tipoDiTurno;  // tipo di utente che attualmente ha accesso alla risorsa
	int numAccessi;        // quanti accessi sono stati fatti da utenti del tipo di turno 
	int numRilasci;        // quanti rilasci sono stati fatti da utenti del tipo di turno 
	Risorsa(){
		attesaUtenti=new HashMap<TipoUtente, Long>();
		attesaUtenti.put(TipoUtente.A, (long) 0);
		attesaUtenti.put(TipoUtente.B, (long) 0);
		attesaUtenti.put(TipoUtente.C, (long) 0);
		assegnaAccesso(TipoUtente.Nessuno);  // inizialmente l'accesso non e` assegnato ad alcun tipo
	}

	// assegna l'accesso al tipo indicato e resetta i contatori
	private void assegnaAccesso(TipoUtente t) {
		System.out.println("*** Risorsa diventa accessibile a "+t);
		numAccessi=0;
		numRilasci=0;
		tipoDiTurno=t;
		attesaUtenti.put(t, (long) 0);
	}

	
	// visualizza la situazione degli accessi
	private void visualizzaSituazione() {
		System.out.print("Risorsa [turno="+tipoDiTurno+", acc="+
				numAccessi+", ril="+numRilasci+" ");
		System.out.print("A: "+attesaUtenti.get(TipoUtente.A)%1000000000+
				" B: "+attesaUtenti.get(TipoUtente.B)%1000000000+
				" C: "+attesaUtenti.get(TipoUtente.C)%1000000000);
		System.out.println("]");
	}

	// richiesta d'accesso da utente di tipo t. BLOCCANTE
	public synchronized void accesso(TipoUtente t) {
		while(true) {
			if(tipoDiTurno==TipoUtente.Nessuno) {
				// nessuno sta occupando la risorsa: la prendo io
				assegnaAccesso(t);
				break; // esco dal ciclo e proseguo a usare la risorsa
			}
			else {
				if(t!=tipoDiTurno || numAccessi==TOT) {
					// la risorsa e` occupata da un altro tipo
					// o dal mio tipo, ma gli accessi sono finiti
					if(attesaUtenti.get(t)==0) {
						attesaUtenti.put(t, System.currentTimeMillis());
					}
					try {
						wait();
					} catch (InterruptedException e) {	}
				} else {
					// la risorsa e` occupata dal mio tipo e gli accessi non sono finiti
					break; // esco dal ciclo e proseguo a usare la risorsa
				}
			}
		}
		numAccessi++;
	}

	// uso della risorsa da perte di un utente
	public synchronized void usa() {
		// come viene usata la risorsa e` irrilevante
	}

	// determina quale tipo di utente e` in attesa da piu` tempo
	// implementazione quick & dirty
	private TipoUtente tipoConAttesaPiuLunga() {
		TipoUtente res = TipoUtente.Nessuno;
		long tA, tB, tC;
		// bisogna scandire la hash e vedere chi ha l'attesa piu` lunga
		tA=attesaUtenti.get(TipoUtente.A);
		tB=attesaUtenti.get(TipoUtente.B);
		tC=attesaUtenti.get(TipoUtente.C);
		if(tA>0 && (tA<=tB || tB==0) && (tA<=tC || tC==0)) {
			res= TipoUtente.A;
		} else {
			if(tB>0 && (tB<=tC || tC==0)) {
				res = TipoUtente.B;
			} else {
				if(tC>0) {
					res = TipoUtente.C;
				}
			}			
		}
		return res;
	}

	// riascio della risorsa
	public synchronized void rilascia() {
		numRilasci++;
		if(numRilasci==TOT || numRilasci==numAccessi) {
			// accessi esauriti per il tipo corrente
			// o nessuno sta usando la risorsa
			visualizzaSituazione();
			// cambio tipo corrente
			TipoUtente t=tipoConAttesaPiuLunga();
			assegnaAccesso(t);
			visualizzaSituazione();
			notifyAll();
		} else {
			// non e` necessario/possibile allocare la risorsa ad altro tipo
			visualizzaSituazione();
		}
	}
}
