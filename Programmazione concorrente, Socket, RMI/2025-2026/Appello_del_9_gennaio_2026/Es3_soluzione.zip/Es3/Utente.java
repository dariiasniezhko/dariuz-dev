import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Random;

public class Utente extends Thread {
	TipoUtente mioTipo;
	InterfRisorsa laRisorsa;
	int mioId;
	Random rnd;
	Utente(int id, TipoUtente t){
		mioId=id;
		mioTipo=t;
		rnd=new Random();
		this.start();
	}
	private void mioOutput(String messaggio) {
		System.out.println("Utente_"+mioId+"("+mioTipo+"): "+messaggio);
	}

	private void dormitina(int t) {
		int durata=1+rnd.nextInt(t);
		try {
			Thread.sleep(durata);
		} catch (InterruptedException e) { }
	}

	public void run() {
		Registry registry;
		try {
			registry = LocateRegistry.getRegistry();
			laRisorsa = (InterfRisorsa)
					registry.lookup("RisorsaPerTipi");
		} catch (RemoteException | NotBoundException e) {
			System.out.println("Client non riesce a connettersi al server");
		}

		int numIterazioni=1+rnd.nextInt(6);
		int numUtizzi=1+rnd.nextInt(3);
		mioOutput("inizio");
		try {
			for(int it=0; it<numIterazioni; it++) {
				mioOutput("provo ad accedere");
				laRisorsa.accesso(mioTipo);
				for(int ut=0; ut<numUtizzi; ut++) {
					mioOutput("uso risorsa");
					laRisorsa.usa();
					dormitina(40);
				}
				mioOutput("rilascio risorsa");
				laRisorsa.rilascia();
				dormitina(100); // simula operazioni che non richiedono la risorsa
			}			
		} catch (Exception e) {
			System.out.println("Fallimento client");
		}
		mioOutput("termino");
	}
}
