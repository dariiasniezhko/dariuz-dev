import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class RisorsaImpl extends UnicastRemoteObject implements InterfRisorsa {
	private static final long serialVersionUID = 1L;
	Risorsa laRisorsa;
	RisorsaImpl() throws RemoteException{
		super();
		laRisorsa=new Risorsa();
	}

	// richiesta d'accesso da utente di tipo t
	public void accesso(TipoUtente t) {
		laRisorsa.accesso(t);
	}

	// uso della risorsa da perte di un utente
	public void usa() {
		// come viene usata la risorsa e` irrilevante
	}

	// riascio della risorsa
	public void rilascia() {
		laRisorsa.rilascia();
	}

	public static void main(String args[]) {
		try {
			Registry registro = LocateRegistry.createRegistry(1099);
			registro.rebind("RisorsaPerTipi", new RisorsaImpl());
			System.err.println("Server ready");
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
}
