import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfRisorsa extends Remote {
	public void accesso(TipoUtente t) throws RemoteException;
	public void usa() throws RemoteException;
	public void rilascia() throws RemoteException;
}
