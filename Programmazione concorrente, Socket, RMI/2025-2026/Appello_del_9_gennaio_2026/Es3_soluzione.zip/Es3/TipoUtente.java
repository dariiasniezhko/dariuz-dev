
public enum TipoUtente {
 A, B, C, Nessuno;
}
