import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Random;

public class Utente extends Thread {
	TipoUtente mioTipo;
	int mioId;
	Random rnd;
	Socket socket;
	ObjectOutputStream out;
	ObjectInputStream in;
	Utente(int id, TipoUtente t){
		mioId=id;
		mioTipo=t;
		rnd=new Random();
		this.start();
	}
	private void mioOutput(String messaggio) {
		System.out.println("Utente_"+mioId+"("+mioTipo+"): "+messaggio);
	}

	private void dormitina(int t) {
		int durata=1+rnd.nextInt(t);
		try {
			Thread.sleep(durata);
		} catch (InterruptedException e) { }
	}

	public void run() {
		int numIterazioni=1+rnd.nextInt(4);
		int numUtizzi=1+rnd.nextInt(3);
		try {
			InetAddress addr = InetAddress.getByName(null);
			Socket socket=new Socket(addr, 8999);
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());
			String ok="";
			mioOutput("inizio");
			for(int it=0; it<numIterazioni; it++) {
				mioOutput("provo ad accedere");
				out.writeObject("accesso"); out.flush();
				out.writeObject(mioTipo); out.flush();
				ok=(String)in.readObject();
				mioOutput("accedo!!!");
				for(int ut=0; ut<numUtizzi; ut++) {
					mioOutput("uso risorsa");
					out.writeObject("usa"); out.flush();
					dormitina(40);
				}
				mioOutput("rilascio risorsa");
				out.writeObject("rilascia"); out.flush();
				dormitina(100); // simula operazioni che non richiedono la risorsa
			}
			out.writeObject("end"); out.flush();
			mioOutput("termino");
			socket.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
