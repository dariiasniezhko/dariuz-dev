import java.util.HashMap;

public class Risorsa {
	final int TOT=6;
	String laRisorsa;      // non rilevante
	HashMap<TipoUtente, Long> attesaUtenti;  // quando hanno iniziato l'attesa i vari tipi di utente
	TipoUtente tipoDiTurno;  // tipo di utente che attualmente ha accesso alla risorsa
	int numAccessi;        // quanti accessi sono stati fatti da utenti del tipo di turno 
	int numRilasci;        // quanti rilasci sono stati fatti da utenti del tipo di turno 
	Risorsa(){
		attesaUtenti=new HashMap<TipoUtente, Long>();
		attesaUtenti.put(TipoUtente.A, (long) 0);
		attesaUtenti.put(TipoUtente.B, (long) 0);
		attesaUtenti.put(TipoUtente.C, (long) 0);
		assegnaAccesso(TipoUtente.Nessuno);  // inizialmente l'accesso non e` assegnato ad alcun tipo
	}

	// assegna l'accesso al tipo indicato e resetta i contatori
	private void assegnaAccesso(TipoUtente t) {
		System.out.println("*** Risorsa diventa accessibile a "+t);
		numAccessi=0;
		numRilasci=0;
		tipoDiTurno=t;
	}

	private void visualizzaAttese() {
		System.out.print("A: "+attesaUtenti.get(TipoUtente.A)%1000000000+
				" B: "+attesaUtenti.get(TipoUtente.B)%1000000000+
				" C: "+attesaUtenti.get(TipoUtente.C)%1000000000);
	}

	
	// visualizza la situazione degli accessi
	private void visualizzaSituazione() {
		System.out.print("Risorsa [turno="+tipoDiTurno+", acc="+
				numAccessi+", ril="+numRilasci+" ");
		visualizzaAttese();
		System.out.println("]");
	}

	// richiesta d'accesso da utente di tipo t
	public synchronized void accesso(TipoUtente t) {
		while(true) {
			if(tipoDiTurno==TipoUtente.Nessuno) {
				// nessuno sta occupando la risorsa: la prendo io
				assegnaAccesso(t);
				attesaUtenti.put(t, (long) 0);
				break;
			}
			else {
				if(t!=tipoDiTurno || numAccessi==TOT) {
					if(attesaUtenti.get(t)==0) {
						attesaUtenti.put(t, System.currentTimeMillis());
					}
					try {
						wait();
					} catch (InterruptedException e) {	}
				} else {
					break;
				}
			}
		}
		numAccessi++;
	}

	// uso della risorsa da perte di un utente
	public synchronized void usa() {
		// come viene usata la risorsa e` irrilevante
	}

	// determina quale tipo di utente e` in attesa da piu` tempo
	private TipoUtente tipoConAttesaPiuLunga() {
		TipoUtente res = TipoUtente.Nessuno;
		long tA, tB, tC;
		// qui bisogna scandire la hash e vedere chi ha l'attesa piu` lunga
		tA=attesaUtenti.get(TipoUtente.A);
		tB=attesaUtenti.get(TipoUtente.B);
		tC=attesaUtenti.get(TipoUtente.C);
		if(tA>0 && (tA<=tB || tB==0) && (tA<=tC || tC==0)) {
			res= TipoUtente.A;
		} else {
			if(tB>0 && (tB<=tC || tC==0)) {
				res = TipoUtente.B;
			} else {
				if(tC>0) {
					res = TipoUtente.C;
				}
			}			
		}
//		visualizzaAttese(); 
//		System.out.println("  ->  tipoConAttesaPiuLunga = "+res);
		return res;
	}

	// riascio della risorsa
	public synchronized void rilascia() {
		numRilasci++;
		if(numRilasci==TOT || numRilasci==numAccessi) {
			visualizzaSituazione();
//			attesaUtenti.put(tipoDiTurno, (long) 0);
			TipoUtente t=tipoConAttesaPiuLunga();
			assegnaAccesso(t);
			attesaUtenti.put(t, (long) 0);
			visualizzaSituazione();
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {}
			notifyAll();
		} else {
			visualizzaSituazione();
		}
	}
}
