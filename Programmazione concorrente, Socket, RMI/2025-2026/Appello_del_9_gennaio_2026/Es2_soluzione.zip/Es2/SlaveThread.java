import java.io.*;
import java.net.Socket;

public class SlaveThread extends Thread {
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	Risorsa laRisorsa;
	protected SlaveThread(Socket s, Risorsa r) throws IOException  {
		socket = s;
		out = new ObjectOutputStream(s.getOutputStream());
		in = new ObjectInputStream(s.getInputStream());
		laRisorsa=r;
	}

	private void exec(String command) {
		System.out.println("Server thread: eseguo comando: "+command);
		try {
			if(command.equals("accesso")) {
				TipoUtente t = (TipoUtente) in.readObject();
				laRisorsa.accesso(t);
				out.writeObject("accesso consentito"); out.flush();
			}
			if(command.equals("usa")) {
				laRisorsa.usa();
			}
			if(command.equals("rilascia")) {
				laRisorsa.rilascia();
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
	public void run() {
		String command;
		try {
			while (true) {
				command = (String) in.readObject();
				if(command.equals("end")) {
					break;
				} else {
					exec(command);
				}
			}
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("IO Exception ");
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				System.err.println("Socket not closed");
			}
		}
	}
}
