
public class IlMain {

	private void exec() {
		final int numIterazioni=3;
		Risorsa laRisorsa=new Risorsa();
		int id=1;
		for(int i=0; i<numIterazioni; i++) {
			new Utente(id++, TipoUtente.A, laRisorsa);
			new Utente(id++, TipoUtente.B, laRisorsa);
			new Utente(id++, TipoUtente.C, laRisorsa);			
		}
	}
	public static void main(String[] args) {
		new IlMain().exec();
		System.out.println("**** main termina");
	}
}
