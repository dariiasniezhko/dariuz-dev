
public class IlMain extends Thread {
	final int NUM_SOTTOPROBLEMI=4;
	Soluzione laSoluzione;
	Solutore[] solutori;

	private void terminaTutti() {
		System.out.println("Main: qualcuno ha segnalato di aver trovato la soluzione");
		System.out.println("Main: "+laSoluzione.getSoluzione());
		// termina tutti i solutori: da fare
	}
	public void run() {
		laSoluzione=new Soluzione();
		solutori= new Solutore[NUM_SOTTOPROBLEMI];
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			solutori[i]=new Solutore(this, new Sottoproblema(i), laSoluzione);
		}
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			solutori[i].start();
		}
		System.out.println("Main: ho lanciato i solutori: adesso aspetto");
		// qui sotto, il main deve uscire dal loop quando arriva segnalazione che
		// la soluzione e` stata trovata: da fare (eventualmente usando terminaTutti())
		try {
			while(true) {
				System.out.println("Main: dormo");
				Thread.sleep(10000);
			}
		} catch (InterruptedException e) {
		}
	}
	public static void main(String[] args) {
		new IlMain().start();
	}
}
