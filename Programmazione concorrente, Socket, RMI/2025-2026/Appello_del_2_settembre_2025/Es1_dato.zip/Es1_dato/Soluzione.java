
public class Soluzione {
	boolean esiste;
	String dettagli; // descrizione della soluzione: inessenziale
	Soluzione(){
		esiste=false;
		dettagli="boh";
	}
	void setSoluzione(String s){
		dettagli=s;
		esiste=true;
	}
	String getSoluzione(){
		return dettagli;
	}

	boolean trovata() {
		return esiste;
	}
}
