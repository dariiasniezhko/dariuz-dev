import java.util.concurrent.ThreadLocalRandom;

public class Solutore extends Thread {
	Sottoproblema sp;
	int mioId;
	Thread mioMain;
	Soluzione laSoluzione;
	public Solutore(Thread m, Sottoproblema s, Soluzione sol) {
		sp=s;
		mioId=s.getId();  // l'identificatore del thread coincide con l'id del sottoproblema
		mioMain=m;
		laSoluzione=sol;
	}
	private void calcola() {
		int a=1;
		System.out.println("Solutore_"+mioId+" calcolo...");
		// irrilevante: facciamo un po' di conti per simulare il calcolo della soluzione
		for(int i=0; i<10000; i++) {
			for(int j=0; j<100000; j++) {
				a=1-a;
			}
		}
	}
	public void run() {
		while(true) {
			calcola();
			if(Thread.currentThread().isInterrupted()) {
				// ho ricevuto interrupt da main mentre calcolavo: termino
				System.out.println("Solutore_"+mioId+" ho ricevuto interrupt da main: termino");
				return;
			}
			if(ThreadLocalRandom.current().nextInt(1000)>990) {
				// decidiamo casualmente se abbiamo trovato la soluzione
				System.out.println("Solutore_"+mioId+" ha trovato la soluzione");
				laSoluzione.setSoluzione("soluzione trovata da solutore "+mioId);
				mioMain.interrupt();
				return;
			}
		}
	}
}
