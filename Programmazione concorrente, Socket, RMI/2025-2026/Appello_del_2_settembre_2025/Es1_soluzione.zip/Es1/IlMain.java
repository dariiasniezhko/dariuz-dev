
public class IlMain extends Thread {
	final int NUM_SOTTOPROBLEMI=4;
	Soluzione laSoluzione;
	Solutore[] solutori;

	private void terminaTutti() {
		// termina tutti i solutori
		System.out.println("Main: qualcuno ha segnalato di aver trovato la soluzione");
		System.out.println("Main: "+laSoluzione.getSoluzione());
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			solutori[i].interrupt();
		}
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			// verifico che gli slave terminino (non proprio necessario)
			try {
				solutori[i].join();
			} catch (InterruptedException e) {	}
		}
	}
	public void run() {
		laSoluzione=new Soluzione();
		solutori= new Solutore[NUM_SOTTOPROBLEMI];
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			solutori[i]=new Solutore(this, new Sottoproblema(i), laSoluzione);
		}
		for(int i=0; i<NUM_SOTTOPROBLEMI; i++) {
			solutori[i].start();
		}
		System.out.println("Main: ho lanciato i solutori: adesso aspetto");
		try {
			while(true) {
				if(Thread.currentThread().isInterrupted()) {
					terminaTutti();
				}
				System.out.println("Main: dormo");
				Thread.sleep(10000);
			}
		} catch (InterruptedException e) {
			// si arriva qui se il main ha ricevuto interrupt durante sleep
			terminaTutti();
		}
	}
	public static void main(String[] args) {
		new IlMain().start();
	}
}
