
public class Soluzione {
	boolean esiste;
	String dettagli; // descrizione della soluzione: inessenziale
	Soluzione(){
		esiste=false;
		dettagli="boh";
	}
	synchronized void setSoluzione(String s){
		dettagli=s;
		esiste=true;
	}
	synchronized String getSoluzione(){
		return dettagli;
	}

	synchronized boolean trovata() {
		return esiste;
	}
}
