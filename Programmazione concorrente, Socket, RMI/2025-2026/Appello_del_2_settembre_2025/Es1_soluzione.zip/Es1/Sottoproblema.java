
public class Sottoproblema {
	int id;
	public Sottoproblema(int i) {
		id=i;
	}
	// il contenuto del sottoproblema e` irrilevante
	int getId() {
		return id;
	}
}
