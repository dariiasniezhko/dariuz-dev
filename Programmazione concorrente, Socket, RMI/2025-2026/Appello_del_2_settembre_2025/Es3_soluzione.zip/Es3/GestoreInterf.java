import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GestoreInterf extends Remote{
	Sottoproblema leggeProblema(SolutoreInterf s) throws RemoteException;
	void scriveSoluzione(Soluzione s) throws RemoteException;
}
