import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class ServerGestore extends UnicastRemoteObject implements GestoreInterf {
	private static final long serialVersionUID = 1L;

	List<SolutoreInterf> clients;
	int numProb;  // numero progressivo sottoproblemi
	Soluzione laSoluzione;
	protected ServerGestore() throws RemoteException {
		super();
		clients=new ArrayList<SolutoreInterf>();
		numProb=0;
		laSoluzione=null;
	}

	public synchronized Sottoproblema leggeProblema(SolutoreInterf s) throws RemoteException {
		System.out.println("Server: ricevuta richiesta. ");
		if(laSoluzione==null) {
			System.out.println("Mando sottoproblema "+numProb);
			clients.add(s);
			return new Sottoproblema(numProb++);
		} else {
			// se la soluzione e` gia` stata trovata
			// non ha piu` senso mandare un sottoproblma
			return null;
		}
	}
	public synchronized void scriveSoluzione(Soluzione s) {
		laSoluzione=s;
		System.out.println("Server: ricevuta soluzione.");		
	}
	private void exec() {
		while(laSoluzione==null) {
			System.out.println("Server: no soluzione: dormo...");		
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {	}
		}
		System.out.println("Server: dico a client di terminare.");		
		for(int i=0; i<numProb; i++) {
			try {
				clients.get(i).termina();
			} catch (RemoteException e) {
				// se e` gia` terminato, amen.
				System.out.println("Server: eccezione su client "+i);
			}
		}
		try {
			unexportObject(this, true);  // termino oggetto remoto server
		} catch (NoSuchObjectException e) {}
	}

	public static void main(String args[]) throws RemoteException {
		Registry reg=LocateRegistry.createRegistry(8999);
		ServerGestore server=new ServerGestore();
		reg.rebind("GestoreSoluzioni", server);
		System.out.println("Server running.");
		server.exec();
	}
}

