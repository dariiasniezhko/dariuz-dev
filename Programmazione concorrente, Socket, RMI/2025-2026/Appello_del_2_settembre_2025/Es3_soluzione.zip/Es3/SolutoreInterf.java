import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SolutoreInterf extends Remote{
	void termina() throws RemoteException;
}
