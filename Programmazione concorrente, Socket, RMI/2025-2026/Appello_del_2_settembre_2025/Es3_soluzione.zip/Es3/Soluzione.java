import java.io.Serializable;

public class Soluzione implements Serializable{
	private static final long serialVersionUID = 1L;
	boolean trovata;
	String dettagli; // inessenziale
	Soluzione(){
		trovata=false;
	}
	void setSoluzione(String s){
		dettagli=s;
		trovata=true;
	}
	boolean esiste() {
		return trovata;
	}
}
