import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ThreadLocalRandom;

public class Solutore extends UnicastRemoteObject implements SolutoreInterf {
	Sottoproblema mioProblema;
	boolean fine;  // indica se si deve terminare l'oggetto remoto client
	protected Solutore() throws RemoteException {
		super();
		fine=false;
	}
	private static final long serialVersionUID = 1L;
	public void termina() throws RemoteException {
		System.out.println("Solutore_"+mioProblema.getId()+" ricevo indicazione di terminare...");
		fine=true;
	}
	private void calcola() {
		int a=1;
		// irrilevante: facciamo un po' di conti per simulare il calcolo della soluzione
		System.out.println("Solutore_"+mioProblema.getId()+" calcolo...");
		for(int i=0; i<100000; i++) {
			for(int j=0; j<100000; j++) {
				a=1-a;
			}
		}
	}
	void exec() {
		GestoreInterf server=null;
		try {
			Registry reg=LocateRegistry.getRegistry(8999);
			server=(GestoreInterf) reg.lookup("GestoreSoluzioni");
		} catch(RemoteException | NotBoundException e) {
			System.out.println("Solutore non trova server");
			System.exit(0);
		}
		try {
			mioProblema=server.leggeProblema(this);
			if(mioProblema!=null) {
				while(!fine) {
					calcola();
					if(ThreadLocalRandom.current().nextInt(10000)>9993) {
						System.out.println("Solutore_"+mioProblema.getId()+" ha trovato la soluzione");
						Soluzione sol=new Soluzione();
						sol.setSoluzione("dettagli soluzione (inessenziali)");
						server.scriveSoluzione(sol);
						break;
					}
				}
				System.out.println("Solutore_"+mioProblema.getId()+" in fondo");
				while(!fine) {
					System.out.println("Solutore_"+mioProblema.getId()+" aspetto fine");
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {	}
				}
				unexportObject(this, true);
			} 
		} catch (RemoteException e) { }
	}
	public static void main(String args[]) {
		Solutore s=null;
		try {
			s = new Solutore();
		} catch (RemoteException e) { }
		s.exec();
	}
}




