import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.LinkedList;
import java.util.List;

public class ServerGestoreProblema {
	final static int MAXWAIT=3000;
	Soluzione laSoluzione;
	int numProb;  // numero progressivo assegnato ai sottoproblemi
	List<SlaveSottoproblema> slaves;
	ServerGestoreProblema(){
		numProb=0;
		laSoluzione=new Soluzione();
		slaves = new LinkedList<SlaveSottoproblema>();
	}
	public void exec() throws IOException {
		ServerSocket s = new ServerSocket(8999);
		System.out.println("Server inizia");
		s.setSoTimeout(MAXWAIT);
		while (true) {
			try {
				Socket socket = s.accept();
				System.out.println("Server accepted connection");
				Sottoproblema pr=new Sottoproblema(numProb++);
				SlaveSottoproblema sl=new SlaveSottoproblema(socket, pr, laSoluzione);
				slaves.add(sl);
				sl.start();
			} catch (SocketTimeoutException e){
				// arriviamo qui se e` scattato il timeout,
				// cioe` non ci sono state connessioni per MAXWAIT msec.
				System.out.println("Server: verifico soluzione ...");
				if(laSoluzione.trovata()) {
					System.out.println("Server: trovata soluzione!");
					break;
				}
			}
		}
		s.close();
		// termina gli slave
		for(SlaveSottoproblema sl: slaves) {
			sl.interrupt();
		}
		System.out.println("Server: chiudo.");
	}
	public static void main(String[] args) throws IOException {
		new ServerGestoreProblema().exec();
	}
}
