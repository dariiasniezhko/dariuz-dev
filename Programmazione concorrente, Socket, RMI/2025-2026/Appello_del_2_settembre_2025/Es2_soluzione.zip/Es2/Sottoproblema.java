import java.io.Serializable;

public class Sottoproblema implements Serializable{
	private static final long serialVersionUID = 1L;
	int id;
	public Sottoproblema(int i) {
		id=i;
	}
	int getId() {
		return id;
	}
	// il contenuto del sottoproblema e` irrilevante
}
