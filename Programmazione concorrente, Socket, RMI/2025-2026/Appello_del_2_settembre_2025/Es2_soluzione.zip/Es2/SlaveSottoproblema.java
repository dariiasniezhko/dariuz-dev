import java.io.*;
import java.net.*;

public class SlaveSottoproblema extends Thread {
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	Soluzione laSoluzione;
	Sottoproblema mioSottoproblema;
	int id;
	protected SlaveSottoproblema(Socket s, Sottoproblema pr, Soluzione sol) throws IOException  {
		socket = s;
		out = new ObjectOutputStream(s.getOutputStream());
		in = new ObjectInputStream(s.getInputStream());
		laSoluzione=sol;
		mioSottoproblema=pr;
	}
	void passoEchiudo() {
		try {
			out.writeObject("fine");
			in.readObject();
		} catch (IOException | ClassNotFoundException e) {
		}
	}
	public void run() {
		String str;
		try {
			out.writeObject(mioSottoproblema);
			str=(String) in.readObject();
		} catch (IOException | ClassNotFoundException e) {
			// gestione eccezione omessa
		}
		while(true) {
			try {
				if(laSoluzione.trovata()) {
					passoEchiudo();
					break;
				} else {
					out.writeObject("manda soluzione");
					str=(String) in.readObject();
					if(!str.equals("<no>")) {
						laSoluzione.setSoluzione(str);
						break;
					}
				}
			} catch (IOException | ClassNotFoundException e) {
				System.err.println("IO Exception ");
			}
			if(this.isInterrupted()) {
				// se e` arrivato  interrupt da master
				passoEchiudo();
				break;
			}
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				// se e` arrivato interrupt da master durante sleep
				passoEchiudo();
				break;
			}
		}
		try {
			socket.close();
		} catch (IOException e) {
			System.err.println("Socket non chiuso normalmente");
		}
	}
}
