import java.io.*;
import java.net.*;
import java.util.concurrent.ThreadLocalRandom;

public class ClientSolutore {
	private int id;
	InetAddress addr;
	Socket socket;
	ObjectOutputStream out;
	ObjectInputStream in;
	Sottoproblema mioSottoproblema=null;
	ClientSolutore() throws IOException {
		addr = InetAddress.getByName(null);
		socket=new Socket(addr, 8999);  // connessione al catalogo
		out = new ObjectOutputStream(socket.getOutputStream());
		in = new ObjectInputStream(socket.getInputStream());
	}

	void myoutput(String s) {
		System.out.println("solutore_"+id+": "+s);
	}
	private void calcola() {
		int a=1;
		// irrilevante: facciamo un po' di conti per simulare il calcolo della soluzione
		myoutput(" calcolo...");
		for(int i=0; i<10000; i++) {
			for(int j=0; j<100000; j++) {
				a=1-a;
			}
		}
	}
	public void exec() {
		try {
			String str;
			mioSottoproblema=(Sottoproblema) in.readObject();
			out.writeObject("ack");
			id=mioSottoproblema.getId();
			while(true) {
				// fase 1: calcolo
				calcola();
				// fase 2: comunicazione
				str=(String) in.readObject();
				myoutput(" ricevuto "+str);
				if(str.equals("manda soluzione")) {
					// decidiamo a caso se abbiamo trovato la soluzione
					int dado= ThreadLocalRandom.current().nextInt(100);
					if(dado>92) {
						out.writeObject("dettagli soluzione per "+id);
						myoutput(" trovato soluzione");
						break;
					} else {
						out.writeObject("<no>");
					}
				}
				if(str.equals("fine")) {
					break;
				}
			} 
			myoutput(" termino");
		}
		catch (IOException | ClassNotFoundException e) {
			// gestione eccezione omessa
		}
	}
	public static void main(String args[]) throws ClassNotFoundException, IOException  {
		new ClientSolutore().exec();
	}
}
