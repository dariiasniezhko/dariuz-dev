import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ServerInterface extends Remote{
	public Risorsa prendi(int rid) throws RemoteException;
	public void lascia(int rid) throws RemoteException;
	public int quanteRisorse() throws RemoteException;
}
