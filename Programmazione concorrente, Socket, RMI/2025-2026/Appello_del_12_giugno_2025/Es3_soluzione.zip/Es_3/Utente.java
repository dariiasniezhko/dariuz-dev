import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Random;

public class Utente {
	Random rnd;
	String myName;
	Utente(int n){
		rnd=new Random();
		myName="Utente_"+n;
	}
	private void myOutput(String msg) {
		System.out.println(myName+" "+msg);
	}
	private void uso(Risorsa r) {
		myOutput(": uso risorsa "+r.getId());
		// codice irrilevante per simulare l'uso della risorsa
		int t=r.getId();
		for(int i=0; i<1000; i++) {
			for(int j=0; j<10000000; j++) {
				t=1-t;
			}            
		}
	}
	public void exec() {
		try {
			Registry reg=LocateRegistry.getRegistry(1099);
			ServerInterface ilDeposito=(ServerInterface) reg.lookup("ServerOper");
			Risorsa r;
			int rid;
			for(int i=0; i<5; i++) {
				rid=rnd.nextInt(ilDeposito.quanteRisorse());  // si decide casualmente a quale risorsa accedere
				myOutput(": cerco di prendere la risorsa "+rid);
				r=ilDeposito.prendi(rid);
				myOutput(": ho preso la risorsa "+r.getId());
				uso(r);
				myOutput(": lascio la risorsa "+r.getId());
				ilDeposito.lascia(rid);
			}
			myOutput(": termino");

		} catch (IOException  | NotBoundException e) {
			e.printStackTrace();
		} 
	}

	public static void main(String[] args) {
		new Utente((int)(System.currentTimeMillis()%1000)).exec();
	}
}