import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class ServerImpl extends UnicastRemoteObject implements ServerInterface {
	private static final long serialVersionUID = 1L;
	DepositoRisorse d;
	public ServerImpl() throws RemoteException {
		super();
		d=new DepositoRisorse(10);
	}
	
	public static void main(String[] args) throws RemoteException {
		ServerImpl obj=new ServerImpl();
		Registry reg=LocateRegistry.createRegistry(1099);
		reg.rebind("ServerOper", obj);
		System.out.println("SERVER ON");
	}

	public Risorsa prendi(int rid) throws RemoteException {
		return d.prendi(rid);
	}

	public void lascia(int rid) throws RemoteException {
		d.lascia(rid);
	}

	public int quanteRisorse() throws RemoteException {
		return d.quanteRisorse();
	}
}
