import java.util.Random;

public class Utente extends Thread {
	DepositoRisorse ilDeposito;
	Random rnd;
	Utente(DepositoRisorse d, int n){
		ilDeposito=d;
		rnd=new Random();
		setName("utente_"+n);
		start();
	}
	private void myOutput(String msg) {
		System.out.println(Thread.currentThread().getName()+" "+msg);
	}
	private void uso(Risorsa r) {
		myOutput(" uso risorsa "+r.getId());
		// codice irrilevante per simulare l'uso della risorsa
		int t=r.getId();
		for(int i=0; i<1000; i++) {
			for(int j=0; j<10000000; j++) {
				t=1-t;
			}			
		}
	}
	public void run() {
		Risorsa r;
		int rid;
		for(int i=0; i<5; i++) {
			rid=rnd.nextInt(ilDeposito.quanteRisorse());
			myOutput(": cerco di prendere la risorsa "+rid);
			r=ilDeposito.prendi(rid);
			myOutput(": ho preso la risorsa "+r.getId());
			uso(r);
			myOutput(": lascio la risorsa "+r.getId());
			ilDeposito.lascia(rid);
		}
		myOutput("termino");
	}
}
