
public class Risorsa {
	int id;
	boolean occupata;
	Risorsa(int nt){
		id=nt;
		// i dettagli del contento della tessera non sono rilevanti
		occupata=false;
	}
	public void prendi() {
		occupata=true;
	}
	public void lascia() {
		occupata=false;
	}
	public boolean presa() {
		return occupata;
	}
	public int getId() {
		return id;
	}
	public String toString() {
		return "ris_"+id+" ["+(occupata?"o":"l")+"]";
	}
}
