
import java.util.Hashtable;

public class DepositoRisorse {
	Hashtable<Integer,Risorsa> risorse;
	int numRisorse;
	public DepositoRisorse(int n) {
		numRisorse=n;
		risorse=new Hashtable<Integer,Risorsa>();
		for(int i=0; i<numRisorse; i++) {
			risorse.put(i, new Risorsa(i));
		}
	}
	public synchronized Risorsa prendi(int rid) {
		Risorsa r=risorse.get(rid);
		while(r.presa()) {
			try {
				System.out.println(Thread.currentThread().getName()+" aspetto la risorsa "+rid+"...");
				wait();
			} catch (InterruptedException e) { }
		}
		r.prendi();
		return r;
	}
	public synchronized void lascia(int rid) {
		Risorsa r=risorse.get(rid);
		r.lascia();
		notifyAll();
	}
	public synchronized int quanteRisorse() {
		return numRisorse;
	}
}
