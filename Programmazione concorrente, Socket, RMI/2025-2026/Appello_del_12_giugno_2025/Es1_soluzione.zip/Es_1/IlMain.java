
public class IlMain {
	static final int numUtenti=4;
	public static void main(String[] args) {
		DepositoRisorse d=new DepositoRisorse(10);
		for(int i=0; i<numUtenti; i++) {
			new Utente(d, i);
		}
	}
}
