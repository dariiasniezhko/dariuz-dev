import java.io.Serializable;

public class Risorsa implements Serializable {
	private static final long serialVersionUID = 1L;
		int id;
	    boolean occupata;
	    Risorsa(int nt){
	        id=nt;
	        // i dettagli della risorsa non sono rilevanti
	        occupata=false;
	    }
	    public void prendi() {
	        occupata=true;
	    }
	    public void lascia() {
	        occupata=false;
	    }
	    public boolean presa() {
	        return occupata;
	    }
	    public int getId() {
	        return id;
	    }
	    public String toString() {
	        return "ris_"+id+" ["+(occupata?"o":"l")+"]";
	    }
	}