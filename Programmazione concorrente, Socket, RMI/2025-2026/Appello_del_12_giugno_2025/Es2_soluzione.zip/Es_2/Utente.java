import java.io.*;
import java.net.*;
import java.util.Random;

public class Utente {
	Socket socket;
	ObjectOutputStream out;
	ObjectInputStream in;
	Random rnd;
	String myName;
	Utente(int n){
		rnd=new Random();
		myName="utente_"+n;
	}
	private void myOutput(String msg) {
		System.out.println(myName+" "+msg);
	}
	private void uso(Risorsa r) {
		myOutput(" uso risorsa "+r.getId());
		// codice irrilevante per simulare l'uso della risorsa
		int t=r.getId();
		for(int i=0; i<1000; i++) {
			for(int j=0; j<10000000; j++) {
				t=1-t;
			}            
		}
	}
	public void exec() {
		try {
			Risorsa r;
			int rid;
			InetAddress IP=InetAddress.getByName(null);
			socket=new Socket(IP, Server.PORT);
			out=new ObjectOutputStream(socket.getOutputStream());
			in=new ObjectInputStream(socket.getInputStream());
			for(int i=0; i<5; i++) {
				out.writeObject("quanteRisorse"); out.flush();
				rid=rnd.nextInt((int) in.readObject());
				//rid=rnd.nextInt(ilDeposito.quanteRisorse());  // si decide casualmente a quale risorsa accedere
				myOutput(": cerco di prendere la risorsa "+rid);
				out.writeObject("prendi"); out.flush();
				out.writeObject(rid); out.flush();
				r=(Risorsa) in.readObject();
				//r=ilDeposito.prendi(rid);
				myOutput(": ho preso la risorsa "+r.getId());
				uso(r);
				myOutput(": lascio la risorsa "+r.getId());
				out.writeObject("lascia"); out.flush();
				out.writeObject(rid); out.flush();
			}
			myOutput("termino");
			out.writeObject("END"); out.flush();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		new Utente((int)System.currentTimeMillis()%1000).exec();
	}
}

