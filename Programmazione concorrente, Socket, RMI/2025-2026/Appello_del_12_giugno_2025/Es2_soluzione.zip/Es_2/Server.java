import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	final static int PORT=4444;
	ServerSocket theServerSocket;
	Socket s;
	DepositoRisorse d;
	public Server() {
		try {
			theServerSocket=new ServerSocket(PORT);
			d=new DepositoRisorse(4);
			System.out.println("SERVER ON");
		} catch (IOException e) {
			System.err.println("Server KO");
			System.exit(0);
		}
	}
	public void exec() throws IOException {
		while(true) {
			s=theServerSocket.accept();
			new ServerSlave(s,d);
		}
	}

	public static void main(String[] args) {
		try {
			new Server().exec();
		} catch (IOException e) {
			System.err.println("Server KO");
			System.exit(0);
		}
	}
}
