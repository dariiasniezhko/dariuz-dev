import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerSlave extends Thread {
	Socket socket;
	DepositoRisorse ilDeposito;
	ObjectOutputStream out;
	ObjectInputStream in;
	public ServerSlave(Socket s, DepositoRisorse dr) throws IOException {
		socket=s;
		ilDeposito=dr;
		out=new ObjectOutputStream(socket.getOutputStream());
		in=new ObjectInputStream(socket.getInputStream());
		start();
	}
	public void run() {
		try {
			String st;
			int ris;
			while(true) {
				st=(String) in.readObject();
				if(st.equals("prendi")) {
					ris=(int) in.readObject();
					out.writeObject(ilDeposito.prendi(ris));
				} else if(st.equals("lascia")) {
					ris=(int) in.readObject();
					ilDeposito.lascia(ris);
				} else if(st.equals("quanteRisorse")) {
					out.writeObject(ilDeposito.quanteRisorse());
				} else if(st.equals("END")) {
					break;
				}
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
