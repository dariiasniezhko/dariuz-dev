
import java.util.Hashtable;

public class DepositoRisorse {
	Hashtable<Integer,Risorsa> risorse;
	int numRisorse;
	public DepositoRisorse(int n) {
		numRisorse=n;
		risorse=new Hashtable<Integer,Risorsa>();
		for(int i=0; i<numRisorse; i++) {
			risorse.put(i, new Risorsa(i));
		}
	}
	public Risorsa prendi(int rid) {
		Risorsa r=risorse.get(rid);
		if(r.presa()) {
			return null;
		} else {
			r.prendi();
			return r;
		}
	}
	public void lascia(int rid) {
		Risorsa r=risorse.get(rid);
		r.lascia();
	}
	public int quanteRisorse() {
		return numRisorse;
	}
}
