import java.util.Random;

public class Utente extends Thread {
	Risorsa laRisorsa;
	int mioId;
	Random rnd;
	Utente(int id, Risorsa r){
		mioId=id;
		laRisorsa=r;
		rnd=new Random();
		this.start();
	}
	private void mioOutput(String messaggio) {
		System.out.println("Utente_"+mioId+": "+messaggio);
	}

	private void dormitina(int t) {
		int durata=1+rnd.nextInt(t);
		try {
			Thread.sleep(durata);
		} catch (InterruptedException e) { }
	}

	public void run() {
		int numIterazioni=1+rnd.nextInt(6);
		int numUtizzi=1+rnd.nextInt(3);
		mioOutput("inizio");
		for(int it=0; it<numIterazioni; it++) {
			mioOutput("provo ad accedere");
			laRisorsa.accesso(mioId);
			for(int ut=0; ut<numUtizzi; ut++) {
				mioOutput("uso risorsa");
				laRisorsa.usa();
				dormitina(40); // simula tempo di utilizzo della risorsa
			}
			mioOutput("rilascio risorsa");
			laRisorsa.rilascia(mioId);
			dormitina(100); // simula operazioni che non richiedono la risorsa
		}
		mioOutput("termino");
	}
}
