import java.util.LinkedList;
import java.util.List;

public class Risorsa {
	String laRisorsa;          // non rilevante
	List<Integer> codaUtenti;  // la coda degli utenti in attesa di accedere
	Risorsa(){
		codaUtenti=new LinkedList<Integer>();
	}

	// visualizza la situazione degli accessi
	private void visualizzaSituazione(String s) {
		System.out.print(s+"[");
		for (Integer number : codaUtenti) {
			System.out.print("user_"+number + " ");
		}
		System.out.println("]");
	}

	// richiesta d'accesso da utente di tipo t
	public synchronized void accesso(int idUtente) {
		visualizzaSituazione("Alla richiesta di accesso: ");
		if(!(codaUtenti.contains(idUtente))) {
			codaUtenti.add(idUtente);  // l'utente si mette in coda
		}
		visualizzaSituazione("Dopo richiesta di accesso: ");
		try {
		    // fino a quando l'utente non e` il primo della coda, aspetta
			while(codaUtenti.get(0)!=idUtente) {
				 try {
					wait();
				} catch (InterruptedException e) { }
			}
			
		} catch(Exception e1) {
			visualizzaSituazione("Eccezione alla richiesta di accesso: ");
			System.exit(0);
		}
	}

	// uso della risorsa da perte di un utente
	public synchronized void usa() {
		// come viene usata la risorsa e` irrilevante
	}

	// riascio della risorsa
	public synchronized void rilascia(int idUtente) {
		if(codaUtenti.get(0)==idUtente) {
			codaUtenti.remove(0);  // l'utente si toglie dalla coda
			visualizzaSituazione("Dopo rilascio: ");
			notifyAll();
		} else {
			// questa condizione non dovrebbe verificarsi mai
			System.out.println("*** coda deteriorata ****");
			visualizzaSituazione("Al rilascio con coda deteriorata: ");
			System.exit(0);
		}
	}
}
