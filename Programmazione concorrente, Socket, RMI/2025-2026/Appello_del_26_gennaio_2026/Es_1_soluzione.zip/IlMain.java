
public class IlMain {

	private void exec() {
		final int numIterazioni=4;
		Risorsa laRisorsa=new Risorsa();
		int id=1;
		for(int i=0; i<numIterazioni; i++) {
			new Utente(id++, laRisorsa);		
		}
	}
	public static void main(String[] args) {
		new IlMain().exec();
		System.out.println("**** main termina");
	}
}
