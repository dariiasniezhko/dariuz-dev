import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfRisorsa extends Remote {
	public void accesso(int id) throws RemoteException;
	public void usa() throws RemoteException;
	public void rilascia(int id) throws RemoteException;
}
