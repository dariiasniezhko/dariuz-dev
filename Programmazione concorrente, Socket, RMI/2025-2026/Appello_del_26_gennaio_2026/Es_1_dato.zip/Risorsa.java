import java.util.LinkedList;
import java.util.List;

public class Risorsa {
	String laRisorsa;          // non rilevante
	List<Integer> codaUtenti;  // la coda degli utenti in attesa di accedere
	Risorsa(){
		codaUtenti=new LinkedList<Integer>();
	}

	// richiesta d'accesso da utente 
	public boolean accesso(int idUtente) {
		if(!(codaUtenti.contains(idUtente))) {
			codaUtenti.add(idUtente);
		}
		if(codaUtenti.get(0)==idUtente) {
			return true;
		}
		return false;
	}

	// uso della risorsa da perte di un utente
	public void usa() {
		// come viene usata la risorsa e` irrilevante
	}

	// riascio della risorsa
	public void rilascia(int idUtente) {
		codaUtenti.remove(0);
	}
}
