
public class LanciaUtenti {
/*
   Scorciatoia per provare il sistema con server e client sulla stessa macchina.
 */
	private void exec() {
		final int numIterazioni=4;
		int id=1;
		for(int i=0; i<numIterazioni; i++) {
			new Utente(id++);		
		}
	}
	public static void main(String[] args) {
		new LanciaUtenti().exec();
		System.out.println("**** main termina");
	}
}
