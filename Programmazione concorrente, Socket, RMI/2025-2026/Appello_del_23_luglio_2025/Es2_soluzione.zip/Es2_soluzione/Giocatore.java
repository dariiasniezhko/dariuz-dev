import java.io.*;
import java.net.*;
import java.util.concurrent.ThreadLocalRandom;

public class Giocatore {
	private int id;
	InetAddress addr;
	Socket socket;
	ObjectOutputStream out;
	ObjectInputStream in;
	int numGiocatori;
	Giocatore() throws IOException {
		addr = InetAddress.getByName(null);
		socket=new Socket(addr, 8999);  // connessione al catalogo
		out = new ObjectOutputStream(socket.getOutputStream());
		in = new ObjectInputStream(socket.getInputStream());
	}

	void myoutput(String s) {
		System.out.println("giocatore_"+id+": "+s);
	}
	int sceltaAttaccato() {
		// irrilevante: scegliamo chi attaccare in modo casuale
		int attaccato=id;
		while(attaccato==id) {
			attaccato=ThreadLocalRandom.current().nextInt(numGiocatori);
		}
		return attaccato;
	}
	public void exec() {
		Mossa m;
		try {
			out.writeObject("aggiunta giocatore");
			id=(int) in.readObject();
			myoutput("attendo inizio");
			out.writeObject("attesa inizio");
			in.readObject(); 			
			out.writeObject("quanti siamo");
			numGiocatori=(int) in.readObject(); 
			while(true) {
				myoutput("attendo turno");
				out.writeObject("attesa turno");
				in.readObject(); 
				out.writeObject("finita");
				if((boolean)in.readObject()) {
					break;
				}
				// qui il giocatore dovrebbe consultare la situazione: omesso perche' irrilevante
				out.writeObject("chi attacca");
				int attaccante=(int) in.readObject(); 			if(attaccante<0) {
					// nessuno mi attacca: tocca a me attaccare
					m=new Mossa(id, sceltaAttaccato(), "mossa_attacco_"+id);
				} else {
					// attaccante mi ha attaccato
					m=new Mossa(id, attaccante, "mossa_difesa_"+id);
				}
				myoutput("eseguo "+m);
				out.writeObject("esecuzione mossa");
				out.writeObject(m);
			} 
			myoutput("termino");
			out.writeObject("end");
		}
		catch (IOException | ClassNotFoundException e) {
			// gestione eccezione omessa
		}
	}
	public static void main(String args[]) throws ClassNotFoundException, IOException  {
		new Giocatore().exec();
	}
}
