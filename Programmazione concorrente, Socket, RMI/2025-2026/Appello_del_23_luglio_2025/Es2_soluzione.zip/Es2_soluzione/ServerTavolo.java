import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTavolo {
	public static final int numGiocatori=4;
	TavoloGioco ilTavolo;
	ServerTavolo(){
		ilTavolo=new TavoloGioco(numGiocatori);
	}
	public void exec() throws IOException {
		int giocatoriPresenti=0;
		ServerSocket s = new ServerSocket(8999);
		System.out.println("Server inizia");
		try {
			while (true) {
				Socket socket = s.accept();
				System.out.println("Server accepted connection");
				new SlaveTavolo(socket, giocatoriPresenti++, ilTavolo).start();
			}
		} finally {
			s.close();
		}
	}
	public static void main(String[] args) throws IOException {
		new ServerTavolo().exec();
	}
}
