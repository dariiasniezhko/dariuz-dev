import java.io.*;
import java.net.*;

public class SlaveTavolo extends Thread {
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	TavoloGioco ilTavolo;
	int id;
	protected SlaveTavolo(Socket s, int n, TavoloGioco t) throws IOException  {
		socket = s;
		out = new ObjectOutputStream(s.getOutputStream());
		in = new ObjectInputStream(s.getInputStream());
		ilTavolo=t;
		id=n;
	}
	public void run() {
		String command;
		try {
			while (true) {
				command = (String) in.readObject();
				if(command.equals("end")) {
					break;
				} else {
					if(command.equals("aggiunta giocatore")) {
						out.writeObject(id);
					}
					if(command.equals("quanti siamo")) {
						out.writeObject(ServerTavolo.numGiocatori);
					}
					if(command.equals("attesa inizio")) {
						ilTavolo.attendoInizio();
						out.writeObject("vai");
					}
					if(command.equals("attesa turno")) {
						ilTavolo.attendoTurno(id);
						out.writeObject("vai");
					}
					if(command.equals("chi attacca")) {
						out.writeObject(ilTavolo.chiMiAttacca(id));
					}
					if(command.equals("esecuzione mossa")) {
						Mossa m=(Mossa) in.readObject();
						ilTavolo.esecuzioneMossa(m);
					}
					if(command.equals("finita")) {
						out.writeObject(ilTavolo.finita());
					}
				}
			}
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("IO Exception ");
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				System.err.println("Socket not closed");
			}
		}

	}
}
