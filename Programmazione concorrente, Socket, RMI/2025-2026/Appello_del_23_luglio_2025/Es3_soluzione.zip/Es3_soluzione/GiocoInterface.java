import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GiocoInterface extends Remote {
	public static final int NUM_GIOCATORI = 4;
	public int aggiuntaGiocatore() throws RemoteException;
	public void attendoInizio() throws RemoteException;
	public void attendoTurno(int id)  throws RemoteException;
	public void esecuzioneMossa(Mossa m) throws RemoteException;
	public boolean finita() throws RemoteException;
	public int chiMiAttacca(int id) throws RemoteException;
}

