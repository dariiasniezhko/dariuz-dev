import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.ThreadLocalRandom;

public class Giocatore {
	GiocoInterface ilGestore;
	int id;
	Giocatore() throws RemoteException, NotBoundException{
		Registry reg=LocateRegistry.getRegistry(1099);
		ilGestore=(GiocoInterface) reg.lookup("ServerGioco");
	}
	void myoutput(String s) {
		System.out.println("giocatore_"+id+": "+s);
	}
	int sceltaAttaccato() {
		// irrilevante: scegliamo chi attaccare in modo casuale
		int attaccato=id;
		while(attaccato==id) {
			attaccato=ThreadLocalRandom.current().nextInt(GiocoInterface.NUM_GIOCATORI);
		}
		return attaccato;
	}
	public void exec() throws RemoteException {
		Mossa m;
		if((id=ilGestore.aggiuntaGiocatore())<0) {
			// se il tavolo e` gia` completo non posso giocare, quindi termino.
			return;
		}
		myoutput("attendo inizio");
		ilGestore.attendoInizio();
		while(true) {
			myoutput("attendo turno");
			ilGestore.attendoTurno(id);
			if(ilGestore.finita()) {
				break;  // partita finita
			}
			int attaccante=ilGestore.chiMiAttacca(id);
			// qui il giocatore dovrebbe consultare la situazione: omesso perche' irrilevante
			if(attaccante<0) {
				// nessuno mi attacca: tocca a me attaccare
				m=new Mossa(id, sceltaAttaccato(), "mossa_attacco_"+id);
			} else {
				// attaccante mi ha attaccato
				m=new Mossa(id, attaccante, "mossa_difesa_"+id);
			}
			myoutput("eseguo "+m);
			ilGestore.esecuzioneMossa(m);
		}
		myoutput("termino");
	}
	public static void main(String[] args) {
		try {
			new Giocatore().exec();
		} catch (RemoteException | NotBoundException e) {
			System.out.println("Client KO");
		}
	}
}
