import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class GiocoImpl extends UnicastRemoteObject implements GiocoInterface {
	private static final long serialVersionUID = 1L;
	int numGiocatori;
	TavoloGioco ilTavolo;
	protected GiocoImpl(int n) throws RemoteException {
		super();
		numGiocatori=n;
		ilTavolo=new TavoloGioco(n);
	}
	public int aggiuntaGiocatore() throws RemoteException {
		return ilTavolo.aggiuntaGiocatore();
	}
	public void attendoInizio() throws RemoteException {
		ilTavolo.attendoInizio();
	}
	public void attendoTurno(int id) throws RemoteException {
		ilTavolo.attendoTurno(id);	
	}
	public void esecuzioneMossa(Mossa m) throws RemoteException {
		ilTavolo.esecuzioneMossa(m);
	}
	public boolean finita() throws RemoteException {
		return ilTavolo.finita();
	}
	public int chiMiAttacca(int id) throws RemoteException {
		return ilTavolo.chiMiAttacca(id);
	}
	public static void main(String[] args) {
		GiocoImpl g;
		try {
			g = new GiocoImpl(4);
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("ServerGioco", g);
		} catch (RemoteException e) {
			System.out.println("Server failure");
		}	
	}
}
