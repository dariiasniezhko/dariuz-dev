import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.ThreadLocalRandom;

class Peer  {
	final int numIterazioni=100;
	int id;
	int numDocs=0;
	String mioNome;
	InetAddress addr;
	Socket socketCatalog;
	ObjectOutputStream out;
	ObjectInputStream in;

	Peer() throws IOException, ClassNotFoundException{
		addr = InetAddress.getByName(null);
		socketCatalog=new Socket(addr, 8999);  // connessione al catalogo
		out = new ObjectOutputStream(socketCatalog.getOutputStream());
		in = new ObjectInputStream(socketCatalog.getInputStream());
		out.writeObject("newPeerId"); // chiede id a catalogo
		id=(int)in.readObject();
		mioNome="Peer_"+id;
		numDocs=0;
	}

	void creaDoc() throws IOException {
		Documento doc=new Documento("titolo_"+id+"_"+numDocs++, "boh"); // crea documento
		// inserimento in server:
		out.writeObject("inserimento"); out.flush();
		out.writeObject(doc); out.flush();
		System.out.println(mioNome+": creato documento "+doc.leggiTitolo());
	}

	public void exec() throws IOException, ClassNotFoundException {
		String titolo;
		int it=0;
		int dado=0;
		creaDoc();
		creaDoc();
		while(it<numIterazioni){
			// decidiamo cosa fare
			dado=ThreadLocalRandom.current().nextInt(6);
			if(dado<1) {
				// aggiungiamo documento
				creaDoc();
			} else {
				// determina casualmente il titolo del documento da usare
				titolo="titolo_"+ThreadLocalRandom.current().nextInt(5)+"_"+
						ThreadLocalRandom.current().nextInt(10);
				out.writeObject("inizioOperazioni"); out.flush();
				out.writeObject(titolo); out.flush();
				if((boolean) in.readObject()) {  // se il documento e` stato trovato e lockato
					it++;
					int numOps=ThreadLocalRandom.current().nextInt(3);
					// operazioni varie sul documento
					System.out.println(mioNome+": uso documento "+titolo);
					for(int itOp=0; itOp<numOps; itOp++) {
						out.writeObject("operazione"); out.flush();
						out.writeObject("argomenti"); out.flush();
						String str=(String) in.readObject(); // ricevo risultato
					}
					out.writeObject("fineOperazioni"); out.flush();  // rilasciamo il documento
				}
			}
		}
		System.out.println(mioNome+": termino ");
		out.writeObject("end"); out.flush();
		out.close();
		in.close();
		socketCatalog.close();
		System.out.println("Peer"+mioNome+" termina main");
	}

	public static void main(String args[]) throws ClassNotFoundException, IOException  {
		new Peer().exec();
	}
}
