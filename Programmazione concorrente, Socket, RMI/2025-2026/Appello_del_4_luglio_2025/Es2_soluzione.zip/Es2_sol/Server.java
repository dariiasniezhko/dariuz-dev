import java.net.*;
import java.io.*;

public class Server {
	int numPeers=0;
	DepositoDocumenti IlDepositoGlobale;
	Server(){
		IlDepositoGlobale= new DepositoDocumenti();
		numPeers=0;
	}
	public void exec() throws IOException {
		ServerSocket s = new ServerSocket(8999);
		System.out.println("Server inizia");
		try {
			while (true) {
				Socket socket = s.accept();
				System.out.println("Server accepted connection");
				new ServerSlave(socket, numPeers++, IlDepositoGlobale).start();
			}
		} finally {
			s.close();
		}
	}
	public static void main(String[] args) throws IOException {
		new Server().exec();
	}
}


