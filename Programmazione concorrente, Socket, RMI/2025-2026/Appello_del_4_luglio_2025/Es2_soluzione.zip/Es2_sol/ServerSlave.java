import java.io.*;
import java.net.Socket;

public class ServerSlave extends Thread {
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	DepositoDocumenti ilDeposito;
	int id=0;
	
	protected ServerSlave(Socket s, int n, DepositoDocumenti d) throws IOException  {
		socket = s;
		out = new ObjectOutputStream(s.getOutputStream());
		in = new ObjectInputStream(s.getInputStream());
		ilDeposito=d;
		id=n;
	}

	public void run() {
		String command;
		String titolo;
		Documento doc;
		try {
			while (true) {
				titolo=null;
				command = (String) in.readObject();
				if(command.equals("end")) {
					break;
				} else {
					if(command.equals("inserimento")) {
						doc=(Documento) in.readObject();
						ilDeposito.inserimento(doc);
					}
					if(command.equals("inizioOperazioni")) {
						titolo=(String) in.readObject();
						doc=ilDeposito.trova(titolo);
						if(doc==null) {
							out.writeObject(false);
						} else {
							doc.occupa();
							out.writeObject(true);
							while(true) {
								// puo` arrivare una sequenza qualunque di opearzioni
								command = (String) in.readObject();
								if(command.equals("fineOperazioni")) {
									doc.libera();
									break;
								}
								else {
									if(!command.equals("operazione")) {
										// bisognerebbe gestire questa violazione del protocollo
									} else {
										String argomenti=(String) in.readObject();
										// calcoliamo un risultato usando gli argomeni [omissis]
										out.writeObject("risultato"); out.flush();
									}
								}
							}
						}
					}
					if(command.equals("newPeerId")) {
						out.writeObject(id);
					}
				}
			}
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("IO Exception ");
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				System.err.println("Socket not closed");
			}
		}
	}
}
