import java.io.Serializable;

public class Documento implements Serializable {
	private static final long serialVersionUID = 1L;
	String titolo;
	String contenuto;
	boolean occupato;
	Documento(String t, String c){
		titolo=t;
		contenuto=c;
		occupato=false;
	}
	public String leggiTitolo() {
		return titolo;
	}
	public String leggi() {
		return contenuto;
	}
	public synchronized void occupa() {
		while(occupato) {
			System.out.println(Thread.currentThread().getName()+" waiting for doc "+titolo);
			try {
				wait();
			} catch (InterruptedException e) { }
		}
		occupato=true;
	}
	public synchronized void libera() {
		notifyAll();
		occupato=false;
	}
	public synchronized boolean occupato() {
		return occupato;
	}
}
