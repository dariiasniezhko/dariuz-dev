import java.util.Hashtable;

public class Catalogo {
	static final int numPeers=4;
	Hashtable<String, PeerInterface> tabellona;
	
	Catalogo(){
		tabellona=new Hashtable<String, PeerInterface>();
	}
	
	public synchronized void inserimento(String tit, PeerInterface dd) {
		tabellona.put(tit, dd);
	}
	
	public synchronized PeerInterface trovaDoc(String titolo) {
		return tabellona.get(titolo);
	}

}
