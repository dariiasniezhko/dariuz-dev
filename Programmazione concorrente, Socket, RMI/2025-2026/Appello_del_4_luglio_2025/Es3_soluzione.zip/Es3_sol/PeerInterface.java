import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PeerInterface extends Remote {
	public void occupa(String titolo) throws RemoteException;
	public void libera(String titolo) throws RemoteException;
	public void usa(String titolo) throws RemoteException;
	public int letturaId() throws RemoteException;
}
