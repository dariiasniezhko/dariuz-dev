import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class CatalogoServer extends UnicastRemoteObject implements CatalogoInterface {
	private static final long serialVersionUID = 1L;
	Catalogo ilCatalogo;
	int numPeers=0;
	protected CatalogoServer() throws RemoteException {
		super();
		ilCatalogo=new Catalogo();
		numPeers=0;
	}

	public void inserimento(String tit, PeerInterface p) throws RemoteException {
		ilCatalogo.inserimento(tit, p);	
	}

	public PeerInterface trovaDoc(String titolo) throws RemoteException {
		return ilCatalogo.trovaDoc(titolo);
	}


	public int newPeerId() throws RemoteException {
		return numPeers++;
	}

	public static void main(String[] args) {
		CatalogoServer cs;
		try {
			cs = new CatalogoServer();
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("Catalogo", cs);
		} catch (RemoteException e) {
			System.out.println("Catalog server failure");
		}
	}
}
