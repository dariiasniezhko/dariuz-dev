import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ThreadLocalRandom;

public class Peer extends UnicastRemoteObject implements PeerInterface  {
	private static final long serialVersionUID = 1L;
	final int numIterazioni=10;
	final int numDocumenti=8;
	private int id;
	private String nome;
	private DepositoDocumenti ilMioDeposito;
	private CatalogoInterface ilCatalogo;

	Peer() throws RemoteException, NotBoundException{
		Registry reg=LocateRegistry.getRegistry(1099);
		ilCatalogo=(CatalogoInterface) reg.lookup("Catalogo");
		id=ilCatalogo.newPeerId();  // riceve id da catalogo
		nome="peer_"+id;
		Thread.currentThread().setName(nome);
		ilMioDeposito=new DepositoDocumenti(id);
		for(int i=0; i<numDocumenti; i++) {
			// crea titolo
			String titolo="titolo_"+100*id+i;
			// inserisce nuovo documento nel deposito locale
			ilMioDeposito.inserimento(new Documento(titolo, "boh"));  // il contenuto del documento e` irrilevante
			// informa il catalogo
			ilCatalogo.inserimento(titolo, (PeerInterface) this);
		}
	}

	public void exec() {
		String titolo=" ";
		PeerInterface altroPeer=null;
		try {
			for(int j=0; j<numIterazioni; j++) {
				boolean trovato=false;
				while (!trovato) {
					// determina casualmnete titolo ocumento da usare
					titolo="titolo_"+100*ThreadLocalRandom.current().nextInt(5)+
							ThreadLocalRandom.current().nextInt(numDocumenti);
					altroPeer=ilCatalogo.trovaDoc(titolo);
					trovato=(altroPeer!=null);
				};
				System.out.println(nome+": mi interessa "+titolo);
				// altroPeer potrebbe essere this, se il titolo cercato e` nel deposito locale
				System.out.println(nome+": trovato "+titolo+" su Peer "+altroPeer.letturaId());
				altroPeer.occupa(titolo);
				altroPeer.usa(titolo);
				altroPeer.libera(titolo);
			}
		} catch (RemoteException e) {
			// qui bisognerebbe gestire l'eccezione...
		}
		System.out.println(nome+": termino ");
	}

	public int letturaId() throws RemoteException {
		return id;
	}
	public void occupa(String titolo) throws RemoteException {
		Documento doc=ilMioDeposito.trova(titolo);
		doc.occupa();
	}
	public void libera(String titolo) throws RemoteException {
		Documento doc=ilMioDeposito.trova(titolo);
		doc.libera();
	}
	public void usa(String titolo) throws RemoteException {
		try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(200, 500));
		} catch (InterruptedException e) {	}
	}
	public static void main(String[] args) {
		try {
			new Peer().exec();
		} catch (RemoteException | NotBoundException e) {
			System.out.println("Peer failure");
		}
	}
}
