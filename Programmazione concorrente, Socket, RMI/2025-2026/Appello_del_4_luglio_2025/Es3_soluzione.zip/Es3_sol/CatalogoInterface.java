import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CatalogoInterface extends Remote {
	public void inserimento(String tit, PeerInterface p) throws RemoteException;
	public PeerInterface trovaDoc(String titolo) throws RemoteException;
	public int newPeerId() throws RemoteException;
}
