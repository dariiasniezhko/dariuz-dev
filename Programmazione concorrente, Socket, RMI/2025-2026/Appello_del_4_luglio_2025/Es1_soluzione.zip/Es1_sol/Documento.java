import java.util.concurrent.ThreadLocalRandom;

public class Documento {
	String titolo;
	String contenuto;
	boolean occupato;
	Documento(String t, String c){
		titolo=t;
		contenuto=c;
		occupato=false;
	}
	public String leggiTitolo() {
		return titolo;
	}
	public String leggi() {
		return contenuto;
	}
	public synchronized void occupa() {
		while(occupato) {
			System.out.println(Thread.currentThread().getName()+" waiting for doc "+titolo+" *********************");
			try {
				wait();
			} catch (InterruptedException e) { }
		}
		occupato=true;
	}
	public synchronized void usa() {
		try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(200, 400));
		} catch (InterruptedException e) {}
	}
	public synchronized void libera() {
		occupato=false;
		notifyAll();
	}
	public synchronized boolean occupato() {
		return occupato;
	}
}
